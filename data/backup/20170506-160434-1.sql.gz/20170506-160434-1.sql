-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 
-- Port     : 
-- Database : 
-- 
-- Part : #1
-- Date : 2017-05-06 16:04:34
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `yf_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `yf_action_log`;
CREATE TABLE `yf_action_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) DEFAULT '0' COMMENT '用户id',
  `object` varchar(100) DEFAULT NULL COMMENT '访问对象的id,格式：不带前缀的表名+id;如news1表示xx_news表里id为1的记录',
  `action` varchar(50) DEFAULT NULL COMMENT '操作名称；格式规定为：应用名+控制器+操作名；也可自己定义格式只要不发生冲突且惟一；',
  `count` int(11) DEFAULT '0' COMMENT '访问次数',
  `last_time` int(11) DEFAULT '0' COMMENT '最后访问的时间戳',
  `ip` varchar(15) DEFAULT NULL COMMENT '访问者最后访问ip',
  `create_time` int(11) DEFAULT NULL,
  `updata_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_object_action` (`uid`,`object`,`action`),
  KEY `user_object_action_ip` (`uid`,`object`,`action`,`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='访问记录表';


-- -----------------------------
-- Table structure for `yf_admin`
-- -----------------------------
DROP TABLE IF EXISTS `yf_admin`;
CREATE TABLE `yf_admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `admin_pid` int(11) NOT NULL DEFAULT '0' COMMENT '0为主账户',
  `admin_auth_group_id` int(11) DEFAULT NULL,
  `admin_username` varchar(80) NOT NULL COMMENT '管理员用户名',
  `admin_officer_id` int(11) DEFAULT NULL,
  `admin_pwd` varchar(70) NOT NULL COMMENT '管理员密码',
  `admin_changepwd` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更改密码时间',
  `admin_email` varchar(30) NOT NULL COMMENT '邮箱',
  `admin_realname` varchar(10) DEFAULT NULL COMMENT '真实姓名',
  `admin_avatar` varchar(255) DEFAULT '' COMMENT '头像',
  `admin_tel` varchar(30) DEFAULT NULL COMMENT '电话号码',
  `admin_hits` int(8) NOT NULL DEFAULT '1' COMMENT '登陆次数',
  `admin_ip` varchar(20) DEFAULT NULL COMMENT 'IP地址',
  `admin_time` int(11) unsigned DEFAULT '0' COMMENT '登陆时间',
  `admin_last_ip` varchar(20) DEFAULT NULL COMMENT '上次登陆ip',
  `admin_last_time` int(11) unsigned DEFAULT '0' COMMENT '上次登陆时间',
  `admin_addtime` int(11) NOT NULL COMMENT '添加时间',
  `admin_mdemail` varchar(50) NOT NULL DEFAULT '0' COMMENT '传递修改密码参数加密',
  `admin_open` tinyint(2) NOT NULL DEFAULT '0' COMMENT '审核状态',
  `login_type` varchar(20) NOT NULL DEFAULT 'ad' COMMENT 'ad 为管理后台账号，‘sys''为系统后台账号',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`admin_id`),
  KEY `admin_auth_group_id` (`admin_auth_group_id`) USING BTREE,
  KEY `admin_username` (`admin_username`) USING BTREE,
  KEY `admin_officer_id` (`admin_officer_id`) USING BTREE,
  KEY `admin_id, admin_pid` (`admin_id`,`admin_pid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_admin`
-- -----------------------------
INSERT INTO `yf_admin` VALUES ('');
INSERT INTO `yf_admin` VALUES ('');
INSERT INTO `yf_admin` VALUES ('');
INSERT INTO `yf_admin` VALUES ('');
INSERT INTO `yf_admin` VALUES ('');

-- -----------------------------
-- Table structure for `yf_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `yf_auth_group`;
CREATE TABLE `yf_auth_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `son_user_id` int(11) NOT NULL,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `is_edit_text` tinyint(1) DEFAULT '0',
  `rules` text,
  `project_ids` varchar(255) DEFAULT '-1' COMMENT '项目ID 多个逗号隔开。不一样的组权限有不同的项目权限',
  `addtime` int(11) NOT NULL COMMENT '添加时间',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `is_delete` tinyint(1) DEFAULT NULL COMMENT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_auth_group`
-- -----------------------------
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');
INSERT INTO `yf_auth_group` VALUES ('');

-- -----------------------------
-- Table structure for `yf_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `yf_auth_group_access`;
CREATE TABLE `yf_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_auth_group_access`
-- -----------------------------
INSERT INTO `yf_auth_group_access` VALUES ('');
INSERT INTO `yf_auth_group_access` VALUES ('');
INSERT INTO `yf_auth_group_access` VALUES ('');
INSERT INTO `yf_auth_group_access` VALUES ('');

-- -----------------------------
-- Table structure for `yf_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `yf_auth_rule`;
CREATE TABLE `yf_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `css` varchar(20) NOT NULL COMMENT '样式',
  `condition` char(100) NOT NULL DEFAULT '',
  `pid` int(5) NOT NULL DEFAULT '0' COMMENT '父栏目ID',
  `level` int(1) unsigned NOT NULL DEFAULT '0' COMMENT '菜单等级',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `id, pid` (`id`,`pid`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=340 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_auth_rule`
-- -----------------------------
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');
INSERT INTO `yf_auth_rule` VALUES ('');

-- -----------------------------
-- Table structure for `yf_city`
-- -----------------------------
DROP TABLE IF EXISTS `yf_city`;
CREATE TABLE `yf_city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `pid` int(11) NOT NULL,
  `levle` int(11) DEFAULT NULL,
  `is_enabled` tinyint(1) DEFAULT '1',
  `sort` int(11) DEFAULT '100',
  `spell` varchar(100) DEFAULT NULL,
  `short_spell` varchar(10) DEFAULT NULL,
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id, pid` (`id`,`pid`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5002 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_city`
-- -----------------------------
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');
INSERT INTO `yf_city` VALUES ('');

-- -----------------------------
-- Table structure for `yf_department_info`
-- -----------------------------
DROP TABLE IF EXISTS `yf_department_info`;
CREATE TABLE `yf_department_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(80) DEFAULT NULL,
  `is_enabled` tinyint(1) DEFAULT '1',
  `sort` int(11) DEFAULT '100',
  `remark` text,
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_department_info`
-- -----------------------------
INSERT INTO `yf_department_info` VALUES ('');
INSERT INTO `yf_department_info` VALUES ('');
INSERT INTO `yf_department_info` VALUES ('');
INSERT INTO `yf_department_info` VALUES ('');
INSERT INTO `yf_department_info` VALUES ('');
INSERT INTO `yf_department_info` VALUES ('');
INSERT INTO `yf_department_info` VALUES ('');
INSERT INTO `yf_department_info` VALUES ('');
INSERT INTO `yf_department_info` VALUES ('');
INSERT INTO `yf_department_info` VALUES ('');
INSERT INTO `yf_department_info` VALUES ('');
INSERT INTO `yf_department_info` VALUES ('');

-- -----------------------------
-- Table structure for `yf_dispatch_config`
-- -----------------------------
DROP TABLE IF EXISTS `yf_dispatch_config`;
CREATE TABLE `yf_dispatch_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `type` varchar(60) DEFAULT NULL COMMENT '分配类型',
  `cycle` varchar(32) DEFAULT '' COMMENT '周期',
  `total_days` int(11) DEFAULT '0',
  `duration_time` varchar(11) DEFAULT NULL COMMENT '有效时间',
  `is_enabled` tinyint(1) DEFAULT '1',
  `dispatch_data` varchar(400) DEFAULT NULL COMMENT '以JSON格式保存 分配条件',
  `is_manual` tinyint(1) DEFAULT NULL,
  `dispatch_auth` varchar(255) DEFAULT NULL COMMENT '拥有可以查看所有数据的成员ID',
  `member_ids` varchar(400) DEFAULT NULL COMMENT '英文都好隔开各个成员ID',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  UNIQUE KEY `group_id` (`group_id`) USING BTREE,
  KEY `user_id` (`user_id`),
  KEY `type` (`type`),
  KEY `is_enabled` (`is_enabled`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_dispatch_config`
-- -----------------------------
INSERT INTO `yf_dispatch_config` VALUES ('');

-- -----------------------------
-- Table structure for `yf_dispatch_count`
-- -----------------------------
DROP TABLE IF EXISTS `yf_dispatch_count`;
CREATE TABLE `yf_dispatch_count` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `dispatch_id` int(11) DEFAULT NULL,
  `officer_id` int(11) DEFAULT NULL,
  `dispatch_num` int(4) DEFAULT NULL COMMENT '分配数量',
  `effective_num` int(4) DEFAULT NULL COMMENT '有效转化量',
  `fail_num` int(4) DEFAULT NULL,
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`),
  KEY `dispatch_id` (`dispatch_id`),
  KEY `officer_id` (`officer_id`),
  KEY `create_time` (`create_time`),
  KEY `update_time` (`update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_dispatch_count`
-- -----------------------------
INSERT INTO `yf_dispatch_count` VALUES ('');
INSERT INTO `yf_dispatch_count` VALUES ('');

-- -----------------------------
-- Table structure for `yf_dispatch_student`
-- -----------------------------
DROP TABLE IF EXISTS `yf_dispatch_student`;
CREATE TABLE `yf_dispatch_student` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `dispatch_id` int(11) DEFAULT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `student_name` varchar(80) DEFAULT NULL,
  `student_phone` varchar(40) DEFAULT NULL,
  `officer_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `dispatch_type` int(3) DEFAULT '1' COMMENT '1为自动分配。2为手动分配',
  `dispatch_status` int(3) DEFAULT NULL COMMENT '分配状态，1为预分配（未接受、可拒绝）（必须有咨询师ID）、2为已分配（必须有咨询ID、已接受）、3正在执行（同时只能执行一个）、4未分配（可不含有咨询师ID）、5为已完成分配任务（已报名）、已完成分配的进行删除不保留是否需要“5”有待验证 、6接单失败 失败原因',
  `dispatch_effective_time` varchar(11) DEFAULT NULL COMMENT '分配有效时间',
  `remark` text,
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`),
  KEY `dispatch_id` (`dispatch_id`),
  KEY `booking_id` (`booking_id`),
  KEY `student_name` (`student_name`),
  KEY `officer_id` (`officer_id`),
  KEY `project_id` (`project_id`),
  KEY `dispatch_type` (`dispatch_type`),
  KEY `dispatch_status` (`dispatch_status`),
  KEY `dispatch_effective_time` (`dispatch_effective_time`),
  KEY `student_phone` (`student_phone`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_dispatch_student`
-- -----------------------------
INSERT INTO `yf_dispatch_student` VALUES ('');

-- -----------------------------
-- Table structure for `yf_diyflag`
-- -----------------------------
DROP TABLE IF EXISTS `yf_diyflag`;
CREATE TABLE `yf_diyflag` (
  `diyflag_id` int(2) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `diyflag_value` char(2) NOT NULL COMMENT '值',
  `diyflag_name` char(10) NOT NULL COMMENT '名称',
  `diyflag_order` int(11) NOT NULL COMMENT '排序',
  PRIMARY KEY (`diyflag_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_diyflag`
-- -----------------------------
INSERT INTO `yf_diyflag` VALUES ('');
INSERT INTO `yf_diyflag` VALUES ('');
INSERT INTO `yf_diyflag` VALUES ('');
INSERT INTO `yf_diyflag` VALUES ('');
INSERT INTO `yf_diyflag` VALUES ('');
INSERT INTO `yf_diyflag` VALUES ('');
INSERT INTO `yf_diyflag` VALUES ('');
INSERT INTO `yf_diyflag` VALUES ('');
INSERT INTO `yf_diyflag` VALUES ('');

-- -----------------------------
-- Table structure for `yf_feedback`
-- -----------------------------
DROP TABLE IF EXISTS `yf_feedback`;
CREATE TABLE `yf_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `runner_id` int(11) DEFAULT NULL,
  `student_name` varchar(225) NOT NULL,
  `sort_spell` varchar(80) DEFAULT NULL,
  `student_phone` varchar(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL COMMENT '顶级项目ID',
  `feedback_time` varchar(11) DEFAULT NULL,
  `depart_id` int(11) DEFAULT NULL COMMENT '部门ID',
  `question_type` int(11) DEFAULT NULL COMMENT '问题类型',
  `urgency` int(3) DEFAULT '1' COMMENT '紧急性：1为低、2为中、3为高',
  `describe` longtext,
  `status` int(3) DEFAULT NULL COMMENT '处理状态：1已处理、2待处理、3处理中、4已处理',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`),
  KEY `student_name` (`student_name`),
  KEY `student_phone` (`student_phone`),
  KEY `project_id` (`project_id`),
  KEY `feedback_time` (`feedback_time`),
  KEY `depart_id` (`depart_id`),
  KEY `question_type` (`question_type`),
  KEY `urgency` (`urgency`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_feedback`
-- -----------------------------
INSERT INTO `yf_feedback` VALUES ('');
INSERT INTO `yf_feedback` VALUES ('');
INSERT INTO `yf_feedback` VALUES ('');
INSERT INTO `yf_feedback` VALUES ('');
INSERT INTO `yf_feedback` VALUES ('');
INSERT INTO `yf_feedback` VALUES ('');

-- -----------------------------
-- Table structure for `yf_feedback_analysis`
-- -----------------------------
DROP TABLE IF EXISTS `yf_feedback_analysis`;
CREATE TABLE `yf_feedback_analysis` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `feedback_num` int(11) NOT NULL DEFAULT '1',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`),
  KEY `project_id` (`project_id`),
  KEY `feedback_num` (`feedback_num`),
  KEY `create_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_feedback_analysis`
-- -----------------------------
INSERT INTO `yf_feedback_analysis` VALUES ('');
INSERT INTO `yf_feedback_analysis` VALUES ('');
INSERT INTO `yf_feedback_analysis` VALUES ('');
INSERT INTO `yf_feedback_analysis` VALUES ('');
INSERT INTO `yf_feedback_analysis` VALUES ('');

-- -----------------------------
-- Table structure for `yf_job_info`
-- -----------------------------
DROP TABLE IF EXISTS `yf_job_info`;
CREATE TABLE `yf_job_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `is_enabled` tinyint(1) DEFAULT '1',
  `remark` text,
  `is_delete` tinyint(1) DEFAULT '0',
  `sort` int(11) DEFAULT '100',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`),
  KEY `title` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_job_info`
-- -----------------------------
INSERT INTO `yf_job_info` VALUES ('');
INSERT INTO `yf_job_info` VALUES ('');
INSERT INTO `yf_job_info` VALUES ('');
INSERT INTO `yf_job_info` VALUES ('');
INSERT INTO `yf_job_info` VALUES ('');
INSERT INTO `yf_job_info` VALUES ('');
INSERT INTO `yf_job_info` VALUES ('');

-- -----------------------------
-- Table structure for `yf_member_group`
-- -----------------------------
DROP TABLE IF EXISTS `yf_member_group`;
CREATE TABLE `yf_member_group` (
  `member_group_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '会员组ID',
  `member_group_name` varchar(30) NOT NULL COMMENT '会员组名',
  `member_group_open` int(11) NOT NULL DEFAULT '0' COMMENT '会员组是否开放',
  `member_group_toplimit` int(11) NOT NULL DEFAULT '0' COMMENT '积分上限',
  `member_group_bomlimit` int(11) NOT NULL DEFAULT '0' COMMENT '积分下限',
  `member_group_order` int(11) NOT NULL COMMENT '排序',
  PRIMARY KEY (`member_group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_member_group`
-- -----------------------------
INSERT INTO `yf_member_group` VALUES ('');

-- -----------------------------
-- Table structure for `yf_member_list`
-- -----------------------------
DROP TABLE IF EXISTS `yf_member_list`;
CREATE TABLE `yf_member_list` (
  `member_list_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_list_username` varchar(60) NOT NULL COMMENT '登录用户名',
  `member_list_pwd` char(32) NOT NULL DEFAULT '' COMMENT '登录密码',
  `member_list_salt` char(10) NOT NULL,
  `member_list_groupid` tinyint(2) NOT NULL COMMENT '所属会员组',
  `member_list_nickname` varchar(30) NOT NULL DEFAULT '' COMMENT '昵称',
  `member_list_province` int(6) DEFAULT NULL COMMENT '城市',
  `member_list_city` int(6) DEFAULT NULL COMMENT '市县',
  `member_list_town` int(6) DEFAULT NULL COMMENT '乡镇',
  `member_list_sex` tinyint(2) NOT NULL DEFAULT '3' COMMENT '1=男  2=女 3=保密',
  `member_list_headpic` varchar(100) DEFAULT NULL COMMENT '会员头像路径',
  `member_list_tel` varchar(20) NOT NULL COMMENT '手机',
  `member_list_email` varchar(50) NOT NULL DEFAULT '' COMMENT '邮箱',
  `member_list_open` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `member_list_addtime` int(11) NOT NULL COMMENT '添加时间戳',
  `member_list_from` varchar(20) DEFAULT '',
  `user_url` varchar(100) DEFAULT '' COMMENT '个人网站',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `signature` varchar(255) DEFAULT '' COMMENT '签名',
  `last_login_ip` varchar(16) DEFAULT '',
  `last_login_time` int(11) unsigned DEFAULT NULL,
  `user_activation_key` varchar(100) DEFAULT '' COMMENT '激活验证',
  `user_status` tinyint(1) DEFAULT '0' COMMENT '0未激活 1激活',
  `score` int(11) unsigned DEFAULT '0' COMMENT '积分',
  `coin` int(11) unsigned DEFAULT '0' COMMENT '金币',
  PRIMARY KEY (`member_list_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_member_list`
-- -----------------------------
INSERT INTO `yf_member_list` VALUES ('');
INSERT INTO `yf_member_list` VALUES ('');

-- -----------------------------
-- Table structure for `yf_menu`
-- -----------------------------
DROP TABLE IF EXISTS `yf_menu`;
CREATE TABLE `yf_menu` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(36) NOT NULL,
  `menu_enname` varchar(50) NOT NULL COMMENT '英文标题',
  `menu_type` int(8) NOT NULL,
  `parentid` int(3) NOT NULL COMMENT '父级id',
  `menu_listtpl` varchar(50) NOT NULL DEFAULT '' COMMENT '列表页模板',
  `menu_newstpl` varchar(50) NOT NULL DEFAULT '' COMMENT '单文章页模板',
  `menu_address` varchar(70) NOT NULL,
  `menu_open` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否开启',
  `listorder` int(7) NOT NULL,
  `menu_img` varchar(100) DEFAULT '' COMMENT '单页缩略图',
  `menu_seo_title` varchar(36) NOT NULL,
  `menu_seo_key` varchar(200) NOT NULL,
  `menu_seo_des` varchar(200) NOT NULL,
  `menu_content` longtext NOT NULL,
  `menu_l` varchar(10) NOT NULL DEFAULT 'zh-cn',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `yf_much_select`
-- -----------------------------
DROP TABLE IF EXISTS `yf_much_select`;
CREATE TABLE `yf_much_select` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `select_val` int(11) DEFAULT NULL,
  `is_enabled` tinyint(1) DEFAULT '1',
  `type` int(80) NOT NULL,
  `sort` int(11) DEFAULT '100',
  `is_delete` tinyint(1) DEFAULT '0',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`),
  KEY `is_enabled` (`is_enabled`),
  KEY `type` (`type`),
  KEY `is_delete` (`is_delete`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_much_select`
-- -----------------------------
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');
INSERT INTO `yf_much_select` VALUES ('');

-- -----------------------------
-- Table structure for `yf_oauth_user`
-- -----------------------------
DROP TABLE IF EXISTS `yf_oauth_user`;
CREATE TABLE `yf_oauth_user` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `oauth_from` varchar(20) NOT NULL COMMENT '用户来源key',
  `name` varchar(30) NOT NULL COMMENT '第三方昵称',
  `head_img` varchar(200) NOT NULL COMMENT '头像',
  `uid` int(20) NOT NULL COMMENT '关联的本站用户id',
  `create_time` datetime NOT NULL COMMENT '绑定时间',
  `last_login_time` datetime NOT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(16) NOT NULL COMMENT '最后登录ip',
  `login_times` int(6) NOT NULL COMMENT '登录次数',
  `user_status` tinyint(2) NOT NULL DEFAULT '1',
  `access_token` varchar(512) NOT NULL,
  `expires_date` int(11) NOT NULL COMMENT 'access_token过期时间',
  `openid` varchar(40) NOT NULL COMMENT '第三方用户id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='第三方用户表';


-- -----------------------------
-- Table structure for `yf_officer_info`
-- -----------------------------
DROP TABLE IF EXISTS `yf_officer_info`;
CREATE TABLE `yf_officer_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emid` int(11) NOT NULL,
  `pid` int(11) DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `son_user_id` int(11) DEFAULT NULL COMMENT '子用户下的数据',
  `name` varchar(255) DEFAULT NULL,
  `sex` int(1) DEFAULT '1',
  `phone` varchar(15) DEFAULT NULL,
  `id_card` varchar(255) DEFAULT NULL COMMENT '身份证',
  `bank_card` varchar(255) DEFAULT NULL COMMENT '银行卡号',
  `bank_title` varchar(255) DEFAULT NULL COMMENT '银行名称，（预留）',
  `job_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL COMMENT '部门ID',
  `position_name` varchar(255) DEFAULT NULL COMMENT '职位名称',
  `job_type` int(1) DEFAULT '1' COMMENT '1为全职，2为兼职',
  `status` int(6) NOT NULL DEFAULT '1' COMMENT '1为在岗，2为离职',
  `entry_time` varchar(11) DEFAULT NULL COMMENT '入职时间',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `phone` (`phone`) USING BTREE,
  KEY `department_id` (`department_id`) USING BTREE,
  KEY `jop_type` (`job_type`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `son_user_id` (`son_user_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_officer_info`
-- -----------------------------
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');
INSERT INTO `yf_officer_info` VALUES ('');

-- -----------------------------
-- Table structure for `yf_options`
-- -----------------------------
DROP TABLE IF EXISTS `yf_options`;
CREATE TABLE `yf_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL COMMENT '配置名',
  `option_value` longtext NOT NULL COMMENT '配置值',
  `autoload` int(2) NOT NULL DEFAULT '1' COMMENT '是否自动加载',
  `create_time` varchar(11) DEFAULT 'zh-cn',
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`option_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='全站配置表';

-- -----------------------------
-- Records of `yf_options`
-- -----------------------------
INSERT INTO `yf_options` VALUES ('');
INSERT INTO `yf_options` VALUES ('');
INSERT INTO `yf_options` VALUES ('');
INSERT INTO `yf_options` VALUES ('');
INSERT INTO `yf_options` VALUES ('');
INSERT INTO `yf_options` VALUES ('');

-- -----------------------------
-- Table structure for `yf_project_info`
-- -----------------------------
DROP TABLE IF EXISTS `yf_project_info`;
CREATE TABLE `yf_project_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT '1' COMMENT '父级ID',
  `user_id` int(11) NOT NULL,
  `title` varchar(80) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `is_enabled` varchar(4) DEFAULT NULL COMMENT '是否显示',
  `sort` int(11) DEFAULT '100',
  `levle` int(11) DEFAULT '1' COMMENT '层级',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0',
  PRIMARY KEY (`id`),
  KEY `id, pid` (`id`,`pid`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `is_enabled` (`is_enabled`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `levle` (`levle`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_project_info`
-- -----------------------------
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');
INSERT INTO `yf_project_info` VALUES ('');

-- -----------------------------
-- Table structure for `yf_route`
-- -----------------------------
DROP TABLE IF EXISTS `yf_route`;
CREATE TABLE `yf_route` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '路由id',
  `full_url` varchar(255) DEFAULT NULL COMMENT '完整url， 如：portal/list/index?id=1',
  `url` varchar(255) DEFAULT NULL COMMENT '实际显示的url',
  `listorder` int(5) DEFAULT '0' COMMENT '排序，优先级，越小优先级越高',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态，1：启用 ;0：不启用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='url路由表';


-- -----------------------------
-- Table structure for `yf_school`
-- -----------------------------
DROP TABLE IF EXISTS `yf_school`;
CREATE TABLE `yf_school` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `province_id` int(80) DEFAULT NULL,
  `city_id` int(80) DEFAULT NULL,
  `area_id` int(80) DEFAULT NULL,
  `area_name` varchar(80) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `linkman_name` varchar(80) DEFAULT NULL,
  `link_phone` varchar(11) DEFAULT NULL,
  `project_ids` varchar(255) DEFAULT NULL,
  `project_levle` int(11) DEFAULT NULL COMMENT '项目级数',
  `longitude` varchar(80) DEFAULT '' COMMENT '经度',
  `latitude` varchar(80) DEFAULT '' COMMENT '纬度',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `province_id, city_id, area_id` (`province_id`,`city_id`,`area_id`) USING BTREE,
  KEY `project_ids` (`project_ids`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_school`
-- -----------------------------
INSERT INTO `yf_school` VALUES ('');
INSERT INTO `yf_school` VALUES ('');
INSERT INTO `yf_school` VALUES ('');
INSERT INTO `yf_school` VALUES ('');
INSERT INTO `yf_school` VALUES ('');
INSERT INTO `yf_school` VALUES ('');
INSERT INTO `yf_school` VALUES ('');
INSERT INTO `yf_school` VALUES ('');

-- -----------------------------
-- Table structure for `yf_slide`
-- -----------------------------
DROP TABLE IF EXISTS `yf_slide`;
CREATE TABLE `yf_slide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `pic_url` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slide_type` int(11) DEFAULT '1' COMMENT '1为后台。其余待定',
  `sort` int(11) DEFAULT '100',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `slide_type` (`slide_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_slide`
-- -----------------------------
INSERT INTO `yf_slide` VALUES ('');
INSERT INTO `yf_slide` VALUES ('');
INSERT INTO `yf_slide` VALUES ('');

-- -----------------------------
-- Table structure for `yf_statistics_booking`
-- -----------------------------
DROP TABLE IF EXISTS `yf_statistics_booking`;
CREATE TABLE `yf_statistics_booking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `statistics_num` int(11) DEFAULT NULL COMMENT '统计数量',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `statistics_num` (`statistics_num`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_statistics_booking`
-- -----------------------------
INSERT INTO `yf_statistics_booking` VALUES ('');
INSERT INTO `yf_statistics_booking` VALUES ('');
INSERT INTO `yf_statistics_booking` VALUES ('');

-- -----------------------------
-- Table structure for `yf_statistics_personal`
-- -----------------------------
DROP TABLE IF EXISTS `yf_statistics_personal`;
CREATE TABLE `yf_statistics_personal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `executor_id` int(11) NOT NULL COMMENT '执行人ID',
  `group_id` int(11) NOT NULL,
  `statistics_num` int(11) DEFAULT NULL COMMENT '统计数量',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `executor_id` (`executor_id`) USING BTREE,
  KEY `group_id` (`group_id`) USING BTREE,
  KEY `statistics_num` (`statistics_num`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_statistics_personal`
-- -----------------------------
INSERT INTO `yf_statistics_personal` VALUES ('');
INSERT INTO `yf_statistics_personal` VALUES ('');
INSERT INTO `yf_statistics_personal` VALUES ('');

-- -----------------------------
-- Table structure for `yf_statistics_project`
-- -----------------------------
DROP TABLE IF EXISTS `yf_statistics_project`;
CREATE TABLE `yf_statistics_project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `statistics_num` int(11) DEFAULT NULL COMMENT '统计数量',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `project_id` (`project_id`) USING BTREE,
  KEY `statistics_num` (`statistics_num`) USING BTREE,
  KEY `create_time` (`create_time`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_statistics_project`
-- -----------------------------
INSERT INTO `yf_statistics_project` VALUES ('');
INSERT INTO `yf_statistics_project` VALUES ('');
INSERT INTO `yf_statistics_project` VALUES ('');

-- -----------------------------
-- Table structure for `yf_student_booking`
-- -----------------------------
DROP TABLE IF EXISTS `yf_student_booking`;
CREATE TABLE `yf_student_booking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `son_user_id` int(11) NOT NULL COMMENT '暂不分子账号',
  `student_id` int(11) DEFAULT NULL,
  `student_name` varchar(80) NOT NULL,
  `sort_spell` varchar(16) DEFAULT NULL,
  `phone` varchar(22) NOT NULL COMMENT '手机号码',
  `counselor_id` int(11) DEFAULT NULL COMMENT '咨询师',
  `province_id` varchar(80) NOT NULL COMMENT '预约省份',
  `city_id` varchar(80) DEFAULT NULL COMMENT '预约城市',
  `area_id` varchar(80) DEFAULT NULL COMMENT '预约区域',
  `school_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1' COMMENT '预约状态 1为未到访；2为已到访；3预约逾期；\r\n\r\n留着处理',
  `booking_date` varchar(11) DEFAULT NULL,
  `booking_time` varchar(22) DEFAULT NULL COMMENT '到访时间',
  `remark` text,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `son_user_id` (`son_user_id`) USING BTREE,
  KEY `student_id` (`student_id`) USING BTREE,
  KEY `student_name` (`student_name`) USING BTREE,
  KEY `sort_spell` (`sort_spell`) USING BTREE,
  KEY `phone` (`phone`) USING BTREE,
  KEY `province_id, city_id, area_id` (`province_id`,`city_id`,`area_id`) USING BTREE,
  KEY `school_id` (`school_id`) USING BTREE,
  KEY `project_id` (`project_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `booking_time` (`booking_time`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_student_booking`
-- -----------------------------
INSERT INTO `yf_student_booking` VALUES ('');
INSERT INTO `yf_student_booking` VALUES ('');
INSERT INTO `yf_student_booking` VALUES ('');
INSERT INTO `yf_student_booking` VALUES ('');

-- -----------------------------
-- Table structure for `yf_student_class`
-- -----------------------------
DROP TABLE IF EXISTS `yf_student_class`;
CREATE TABLE `yf_student_class` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `curriculum_id` int(11) DEFAULT NULL COMMENT '课程ID（项目子ID）',
  `project_id` int(11) DEFAULT NULL COMMENT '项目主ID',
  `start_class_time` varchar(11) DEFAULT NULL COMMENT '上课时间',
  `end_class_time` varchar(11) DEFAULT NULL,
  `techer_id` int(11) DEFAULT NULL COMMENT '老师ID（员工ID）',
  `class_rule` text,
  `school_id` int(11) DEFAULT NULL,
  `students_count` int(11) DEFAULT NULL COMMENT '招生数量',
  `total_classes` int(11) DEFAULT NULL,
  `class_hour` varchar(80) DEFAULT NULL COMMENT '课时',
  `schedule_id` int(11) DEFAULT NULL COMMENT '排课ID',
  `status` varchar(255) DEFAULT '2' COMMENT '1为未开课、2开课中、3已结束',
  `summary` text COMMENT '班级介绍',
  `is_enabled` tinyint(1) DEFAULT '1',
  `recorder_id` int(11) DEFAULT NULL COMMENT '记录人',
  `remark` text,
  `is_delete` tinyint(1) DEFAULT '0',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `techer_id` (`techer_id`) USING BTREE,
  KEY `school_id` (`school_id`) USING BTREE,
  KEY `schedule_id` (`schedule_id`) USING BTREE,
  KEY `class_time` (`start_class_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_student_class`
-- -----------------------------
INSERT INTO `yf_student_class` VALUES ('');
INSERT INTO `yf_student_class` VALUES ('');
INSERT INTO `yf_student_class` VALUES ('');
INSERT INTO `yf_student_class` VALUES ('');

-- -----------------------------
-- Table structure for `yf_student_file`
-- -----------------------------
DROP TABLE IF EXISTS `yf_student_file`;
CREATE TABLE `yf_student_file` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `student_id` int(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type` varchar(80) DEFAULT 'img',
  `student_data` text,
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `student_id` (`student_id`),
  KEY `user_id` (`user_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_student_file`
-- -----------------------------
INSERT INTO `yf_student_file` VALUES ('');
INSERT INTO `yf_student_file` VALUES ('');
INSERT INTO `yf_student_file` VALUES ('');
INSERT INTO `yf_student_file` VALUES ('');
INSERT INTO `yf_student_file` VALUES ('');
INSERT INTO `yf_student_file` VALUES ('');
INSERT INTO `yf_student_file` VALUES ('');
INSERT INTO `yf_student_file` VALUES ('');
INSERT INTO `yf_student_file` VALUES ('');

-- -----------------------------
-- Table structure for `yf_student_info`
-- -----------------------------
DROP TABLE IF EXISTS `yf_student_info`;
CREATE TABLE `yf_student_info` (
  `id` int(11) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '咨询师ID，登陆者ID',
  `son_user_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL COMMENT '姓名',
  `emergency_contact` varchar(80) DEFAULT '' COMMENT '紧急联系人',
  `sort_spell` varchar(11) DEFAULT NULL,
  `id_card` varchar(22) NOT NULL COMMENT '身份证',
  `birthday` varchar(11) DEFAULT NULL,
  `phone_1` varchar(11) DEFAULT NULL COMMENT '手机号码（唯一判断）',
  `phone_2` varchar(11) DEFAULT NULL,
  `QQ` varchar(11) DEFAULT NULL,
  `wechat` varchar(80) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `head_pic` varchar(255) DEFAULT NULL,
  `sex` int(1) DEFAULT '3' COMMENT '1为男性；2为女性；3为保密',
  `education_id` int(11) DEFAULT NULL COMMENT '学历，1为初中，2为高中，3为中专，4为大专，5为本科，6',
  `school_id` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL COMMENT '学员状态：1为流失;2为已报名；3考虑中；',
  `student_source` int(11) DEFAULT '2' COMMENT '客户来源：自来=1；咨询==2；自营==3；其他==4',
  `payable_fee` decimal(11,0) DEFAULT '0' COMMENT '应付金额',
  `paid_fee` decimal(11,0) DEFAULT '0' COMMENT '已付金额',
  `debt_fee` decimal(11,0) DEFAULT '0' COMMENT '欠款费用',
  `runner_id` int(11) DEFAULT NULL COMMENT '接待人ID',
  `nibs_id` int(11) DEFAULT NULL,
  `arrive_time` varchar(11) DEFAULT NULL COMMENT '到达时间',
  `counselor_id` int(11) DEFAULT NULL COMMENT '咨询师',
  `instructor_id` int(11) DEFAULT NULL COMMENT '课程顾问',
  `last_sign_time` varchar(11) DEFAULT NULL COMMENT '最近一次报名时间',
  `remark` text COMMENT '备注',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `phone_1` (`phone_1`) USING BTREE,
  KEY `phone_2` (`phone_2`) USING BTREE,
  KEY `QQ` (`QQ`) USING BTREE,
  KEY `education_id` (`education_id`) USING BTREE,
  KEY `school_id` (`school_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `student_source` (`student_source`) USING BTREE,
  KEY `runner_id` (`runner_id`) USING BTREE,
  KEY `last_sign_time` (`last_sign_time`) USING BTREE,
  KEY `id_card` (`id_card`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_student_info`
-- -----------------------------
INSERT INTO `yf_student_info` VALUES ('');
INSERT INTO `yf_student_info` VALUES ('');
INSERT INTO `yf_student_info` VALUES ('');
INSERT INTO `yf_student_info` VALUES ('');
INSERT INTO `yf_student_info` VALUES ('');
INSERT INTO `yf_student_info` VALUES ('');
INSERT INTO `yf_student_info` VALUES ('');
INSERT INTO `yf_student_info` VALUES ('');
INSERT INTO `yf_student_info` VALUES ('');
INSERT INTO `yf_student_info` VALUES ('');
INSERT INTO `yf_student_info` VALUES ('');
INSERT INTO `yf_student_info` VALUES ('');
INSERT INTO `yf_student_info` VALUES ('');
INSERT INTO `yf_student_info` VALUES ('');
INSERT INTO `yf_student_info` VALUES ('');

-- -----------------------------
-- Table structure for `yf_student_pay_log`
-- -----------------------------
DROP TABLE IF EXISTS `yf_student_pay_log`;
CREATE TABLE `yf_student_pay_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `son_user_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `pay_type` int(11) DEFAULT NULL,
  `flow_id` varchar(64) DEFAULT NULL,
  `student_project_id` int(11) DEFAULT NULL,
  `payable_fee` decimal(11,0) DEFAULT NULL COMMENT '应付',
  `discount_fee` decimal(11,0) DEFAULT '0' COMMENT '优惠',
  `paid_fee` decimal(11,0) DEFAULT NULL COMMENT '实付',
  `debt_fee` decimal(11,0) DEFAULT NULL,
  `pay_time` varchar(11) DEFAULT NULL,
  `pay_income` int(2) DEFAULT '1' COMMENT '1为收入，2为退款（支出）',
  `remark` text,
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `student_id` (`student_id`) USING BTREE,
  KEY `project_id` (`project_id`) USING BTREE,
  KEY `pay_type` (`pay_type`) USING BTREE,
  KEY `pay_time` (`pay_time`) USING BTREE,
  KEY `son_user_id` (`son_user_id`) USING BTREE,
  KEY `flow_id` (`flow_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_student_pay_log`
-- -----------------------------
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');
INSERT INTO `yf_student_pay_log` VALUES ('');

-- -----------------------------
-- Table structure for `yf_student_project`
-- -----------------------------
DROP TABLE IF EXISTS `yf_student_project`;
CREATE TABLE `yf_student_project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT '记录人ID 也是',
  `son_user_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL COMMENT '学员ID',
  `project_id` int(11) DEFAULT NULL COMMENT '项目ID',
  `sign_up_time` varchar(11) DEFAULT NULL COMMENT '报名时间',
  `school_id` int(11) DEFAULT NULL COMMENT '学校ID',
  `counselor_id` int(11) DEFAULT NULL COMMENT '指导员ID（咨询师）',
  `runner_id` int(11) DEFAULT NULL COMMENT '接待老师ID',
  `instructor_id` int(11) DEFAULT NULL COMMENT '课程顾问ID',
  `pay_type` int(11) DEFAULT NULL,
  `pay_status` int(11) DEFAULT '1' COMMENT '付款状态 1为分期付款，2为未付款；3为已结清',
  `project_price` decimal(10,2) DEFAULT NULL,
  `payable_fee` decimal(11,2) DEFAULT '0.00' COMMENT '应付金额',
  `paid_fee` decimal(11,2) DEFAULT '0.00' COMMENT '已付金额',
  `discount_fee` decimal(11,2) DEFAULT '0.00' COMMENT '优惠费用',
  `debt_fee` decimal(11,2) DEFAULT '0.00' COMMENT '欠款费用',
  `province_id` varchar(80) NOT NULL COMMENT '预约省份',
  `city_id` varchar(80) DEFAULT NULL COMMENT '预约城市',
  `area_id` varchar(80) DEFAULT NULL COMMENT '预约区域',
  `status` int(11) DEFAULT NULL COMMENT '报名状态',
  `location_id` int(11) DEFAULT NULL COMMENT '收费地点',
  `class_id` int(11) DEFAULT NULL,
  `sundry_ids` varchar(255) DEFAULT NULL COMMENT '学杂费ID 字符串格式',
  `study_status` int(11) DEFAULT '1' COMMENT '1为就读中、2为已毕业、3为休学、4为退学、5为未培训',
  `remark` text,
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `student_id` (`student_id`) USING BTREE,
  KEY `project_id` (`project_id`) USING BTREE,
  KEY `school_id` (`school_id`) USING BTREE,
  KEY `counselor_id` (`counselor_id`) USING BTREE,
  KEY `runner_id` (`runner_id`) USING BTREE,
  KEY `instructor_id` (`instructor_id`) USING BTREE,
  KEY `pay_type` (`pay_type`) USING BTREE,
  KEY `province_id, city_id, area_id` (`province_id`,`city_id`,`area_id`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `pay_status` (`pay_status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_student_project`
-- -----------------------------
INSERT INTO `yf_student_project` VALUES ('');
INSERT INTO `yf_student_project` VALUES ('');
INSERT INTO `yf_student_project` VALUES ('');
INSERT INTO `yf_student_project` VALUES ('');
INSERT INTO `yf_student_project` VALUES ('');
INSERT INTO `yf_student_project` VALUES ('');
INSERT INTO `yf_student_project` VALUES ('');
INSERT INTO `yf_student_project` VALUES ('');
INSERT INTO `yf_student_project` VALUES ('');
INSERT INTO `yf_student_project` VALUES ('');
INSERT INTO `yf_student_project` VALUES ('');
INSERT INTO `yf_student_project` VALUES ('');

-- -----------------------------
-- Table structure for `yf_student_visit`
-- -----------------------------
DROP TABLE IF EXISTS `yf_student_visit`;
CREATE TABLE `yf_student_visit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `sort_spell` varchar(80) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `counselor_id` int(11) DEFAULT NULL COMMENT '咨询师',
  `project_id` int(11) DEFAULT NULL,
  `is_sign` tinyint(1) DEFAULT '0' COMMENT '是否已经报名',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `name` (`name`) USING BTREE,
  KEY `sort_spell` (`sort_spell`) USING BTREE,
  KEY `phone` (`phone`) USING BTREE,
  KEY `school_id` (`school_id`) USING BTREE,
  KEY `project_id` (`project_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_student_visit`
-- -----------------------------
INSERT INTO `yf_student_visit` VALUES ('');
INSERT INTO `yf_student_visit` VALUES ('');

-- -----------------------------
-- Table structure for `yf_sundry_fee`
-- -----------------------------
DROP TABLE IF EXISTS `yf_sundry_fee`;
CREATE TABLE `yf_sundry_fee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `fee` decimal(11,2) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `type` int(3) DEFAULT '1' COMMENT '1课本费，2文具、3器材、4工本费、5考试费用、6教材费、7其他费用',
  `recorder_id` int(11) DEFAULT NULL COMMENT '录入人ID',
  `is_enabled` tinyint(1) DEFAULT '1',
  `is_delete` tinyint(1) DEFAULT '0',
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `project_id` (`project_id`) USING BTREE,
  KEY `fee` (`fee`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY ` is_delete` (`is_delete`) USING BTREE,
  KEY `recorder_id` (`recorder_id`) USING BTREE,
  KEY ` is_enabled` (`is_enabled`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_sundry_fee`
-- -----------------------------
INSERT INTO `yf_sundry_fee` VALUES ('');
INSERT INTO `yf_sundry_fee` VALUES ('');
INSERT INTO `yf_sundry_fee` VALUES ('');
INSERT INTO `yf_sundry_fee` VALUES ('');
INSERT INTO `yf_sundry_fee` VALUES ('');
INSERT INTO `yf_sundry_fee` VALUES ('');
INSERT INTO `yf_sundry_fee` VALUES ('');
INSERT INTO `yf_sundry_fee` VALUES ('');
INSERT INTO `yf_sundry_fee` VALUES ('');

-- -----------------------------
-- Table structure for `yf_web_config`
-- -----------------------------
DROP TABLE IF EXISTS `yf_web_config`;
CREATE TABLE `yf_web_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `log_pic` varchar(255) DEFAULT NULL,
  `web_title` varchar(255) DEFAULT NULL,
  `web_copyright` text,
  `notic` text,
  `create_time` varchar(11) DEFAULT NULL,
  `update_time` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `yf_web_config`
-- -----------------------------
INSERT INTO `yf_web_config` VALUES ('');
